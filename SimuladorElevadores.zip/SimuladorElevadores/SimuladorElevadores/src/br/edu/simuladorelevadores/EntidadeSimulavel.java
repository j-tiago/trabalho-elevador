package br.edu.simuladorelevadores;

public interface EntidadeSimulavel {
    void atualizar(int minutoSimulado);
}
package br.edu.simuladorelevadores;

public class Main {
    public static void main(String[] args) {
        new Simulador();
    }
}
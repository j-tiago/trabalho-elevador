package br.edu.simuladorelevadores;

public class PainelConfig {
}
